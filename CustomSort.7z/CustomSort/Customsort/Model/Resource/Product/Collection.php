<?php

/**
 * Product collection
 *
 * @category    Fabelio
 * @package     Fabelio_Customsort
 * @author      Maria Angelina <maria@fabelio.com>
 */
class Fabelio_Customsort_Model_Resource_Product_Collection extends Mage_Catalog_Model_Resource_Product_Collection {

    /**
     * Add custom attribute to sort order
     *
     * @param string $attribute
     * @param string $dir
     * @return Mage_Catalog_Model_Resource_Product_Collection
     */
    public function addAttributeToSort($attribute, $dir = self::SORT_ORDER_ASC) {
        if (Mage::app()->getStore()->getId() == Mage_Core_Model_App::ADMIN_STORE_ID) {
            return parent::addAttributeToSort($attribute, $dir);
        }
        if ($attribute == 'discount') {
            $this->addExpressionAttributeToSelect('discount_percent_value', '(({{price}} - final_price) / {{price}})', array('price'));
            if ($dir == self::SORT_ORDER_DESC) {
                $dir = self::SORT_ORDER_DESC;
            } else {
                $dir = self::SORT_ORDER_ASC;
            }
            $this->getSelect()->order(array('discount_percent_value ' . $dir));
            $routeName = Mage::app()->getRequest()->getRouteName();
            if ($routeName=="amlanding") {
                $this->getSelect()->order(array('amlanding_cp.position ' . 'ASC'));                
            } else {
                $this->getSelect()->order(array('position ' . 'ASC'));
            }
            return $this;
        }

        return parent::addAttributeToSort($attribute, $dir);
    }

}
