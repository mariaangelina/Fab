<?php

$installer = $this;
$installer->startSetup();

try {
    $installer->updateAttribute('catalog_product', 'discount', 'used_for_sort_by', 1);
} catch (Exception $e) {
    throw new Exception('Fabelio Customsort : Update Attribute Failed. ' . $e->getMessage());
}

$installer->endSetup();
